/*	Public domain	*/
/*
 * Edition tools built into the VG library.
 */

VG_ToolOps *vgTools[] = {
/*	&vgSelectTool, */
	&vgPointTool,
	&vgLineTool,
	&vgCircleTool,
	&vgProximityTool,
	&vgTextTool,
	&vgPolygonTool,
	NULL
};
