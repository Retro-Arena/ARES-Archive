/*	Public domain	*/

#include <agar/core/begin.h>
__BEGIN_DECLS
int AG_Getopt(int, char * const [], const char *, char **, int *);
__END_DECLS
#include <agar/core/close.h>
