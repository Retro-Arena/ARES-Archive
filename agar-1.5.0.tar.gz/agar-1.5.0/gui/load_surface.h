/*	Public domain	*/

#include <agar/gui/begin.h>
__BEGIN_DECLS
AG_Surface *AG_ReadSurface(AG_DataSource *);
void        AG_WriteSurface(AG_DataSource *, AG_Surface *);
__END_DECLS
#include <agar/gui/close.h>
