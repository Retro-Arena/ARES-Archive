/*	Public domain	*/

#include <agar/gui/begin.h>
__BEGIN_DECLS
AG_Color AG_ReadColor(AG_DataSource *);
void     AG_WriteColor(AG_DataSource *, AG_Color);
__END_DECLS
#include <agar/gui/close.h>
