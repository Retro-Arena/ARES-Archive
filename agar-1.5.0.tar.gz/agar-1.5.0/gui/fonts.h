#include <agar/gui/begin.h>
__BEGIN_DECLS
extern AG_StaticFont agFontVera;
extern AG_StaticFont agFontMinimal;
extern AG_StaticFont agFontMinimalSerif;
__END_DECLS
#include <agar/gui/close.h>
