#define VERSION		2
#define REVISION	1
#define DATE		"30.03.2009"
#define VERS		"Atari800 2.1.0"
#define VSTRING		"Atari800 2.1.0 (30.03.2009)\r\n"
#define VERSTAG		"\0$VER: Atari800 2.1.0 (30.03.2009)"
