#ifndef JAVANVM_INPUT_H_
#define JAVANVM_INPUT_H_

int JAVANVM_INPUT_Initialise(int *argc, char *argv[]);

#endif /* JAVANVM_INPUT_H_ */
