#ifndef JAVANVM_VIDEO_H_
#define JAVANVM_VIDEO_H_

int JAVANVM_VIDEO_Initialise(int *argc, char *argv[]);

#endif /* JAVANVM_VIDEO_H_ */
