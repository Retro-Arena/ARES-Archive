#ifndef SDL_INIT_H_
#define SDL_INIT_H_

int SDL_INIT_Initialise(void);
void SDL_INIT_Exit(void);

#endif /* SDL_INIT_H_ */
