#ifndef _RENDER_GDI_H_
#define _RENDER_GDI_H_

#include "screen_win32.h" 

void refreshv_gdi(UBYTE *scr_ptr, FRAMEPARAMS *fp);

#endif

