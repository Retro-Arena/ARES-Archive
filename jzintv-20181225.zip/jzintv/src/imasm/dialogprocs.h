#ifndef DIALOGPROCS_H_INCLUDED
#define DIALOGPROCS_H_INCLUDED

INT_PTR CALLBACK AboutProc(HWND hDlg, UINT msg, WPARAM wParam, LPARAM lParam);
INT_PTR CALLBACK NewProjectProc(HWND hDlg, UINT msg, WPARAM wParam, LPARAM lParam);

#endif
