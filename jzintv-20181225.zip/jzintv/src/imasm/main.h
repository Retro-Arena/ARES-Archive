#ifndef MAIN_H_INCLUDED
#define MAIN_H_INCLUDED

#ifndef MAX_PATH
    #define MAX_PATH 255
#endif

#define IMASMVERSION "2.2"

void OutputLicense();
void OutputHelp();

#endif

