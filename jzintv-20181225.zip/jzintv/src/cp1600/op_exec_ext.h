
#ifndef CP1600_OP_EXEC_EXT_H_
#define CP1600_OP_EXEC_EXT_H_

int fn_ext_isa(const instr_t *instr, cp1600_t *cp1600);

#endif

