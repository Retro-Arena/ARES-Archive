/* Auto generated, do not edit */

#include "cp1600/op_tables.h"
const cp1600_ins_t fn_rot_1op[] =
{
/*0000*/     fn_SWAP1_r,
/*0001*/     fn_SWAP2_r,
/*0010*/     fn_SLL1_r,
/*0011*/     fn_SLL2_r,
/*0100*/     fn_RLC1_r,
/*0101*/     fn_RLC2_r,
/*0110*/     fn_SLLC1_r,
/*0111*/     fn_SLLC2_r,
/*1000*/     fn_SLR1_r,
/*1001*/     fn_SLR2_r,
/*1010*/     fn_SAR1_r,
/*1011*/     fn_SAR2_r,
/*1100*/     fn_RRC1_r,
/*1101*/     fn_RRC2_r,
/*1110*/     fn_SARC1_r,
/*1111*/     fn_SARC2_r,
};
