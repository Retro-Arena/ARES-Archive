/* Auto generated, do not edit */

#include "cp1600/op_tables.h"
const cp1600_ins_t fn_impl_1op_a[] =
{
/*00*/   fn_HLT,
/*01*/   fn_SDBD,
/*10*/   fn_EIS,
/*11*/   fn_DIS,
};
